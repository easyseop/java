package practice.이지섭_2017112513_0519;

class Animal {
    private String feed;
    Animal(String feed){
        this.feed = feed;
    }
     void get_feed(){
         System.out.print(feed);
    }

}
